# Empirical Formula Solver

Project for IB Comp Sci IA 2016:
Solving Empirical Formulas.  This program will take in the values of percents of atoms in an unknown molecule, calculate the amount of each atom in the molecule, and then return the Empirical Formula of the molecule.
<br /> 
Currently, I will be using an enum for the elements created by Felix Divo

The Program takes in the number of elements the user wants to calculate for (max 5).  The user enters values for elements and percents and the compound is returned to the user.  The option to see the steps taken to get to the final result is available after a calculation has been done.

This will be displayed using Swing.  All numbers will be estimates to the best the program can do.
